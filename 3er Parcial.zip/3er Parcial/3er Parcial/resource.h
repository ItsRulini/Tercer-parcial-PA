//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por 3er Parcial.rc
//
#define IDD_MAIN_WINDOW                 101
#define IDR_MENU1                       103
#define IDD_VENTA_BOLETOS               104
#define IDD_MIS_COMPRAS                 105
#define IDD_EVENTOS_MES                 106
#define IDC_INICIO_SESION               1001
#define IDC_COMPRAR                     1001
#define IDC_USER_NAME                   1002
#define IDC_COMBO_EVENTOS               1003
#define IDC_COSTO_EVENTO                1004
#define IDC_LIST_COMPRAS                1005
#define IDC_COMBO_EVENTOS2              1005
#define IDC_COMBO_PROMO                 1005
#define ID_MISCOMPRAS                   40001
#define ID_EVENTOSDELMES                40002
#define ID_VENTADEBOLETOS               40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
