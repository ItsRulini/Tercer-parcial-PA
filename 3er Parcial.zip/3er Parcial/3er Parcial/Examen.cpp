#include <Windows.h>
#include <CommCtrl.h>
#include <cstdio>
#include"resource.h"

#define IVA 1.16

LRESULT CALLBACK cVentanaRegistro(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK cVentanaDeCompras(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK cVentanaEventos(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK cVentanaVentaBoletos(HWND, UINT, WPARAM, LPARAM);

struct Compras
{
	//char nombreEvento[30], fecha[20];
	int indiceEvento = 0;
	int indicePromo = 0;
	char precio[30];
	Compras* siguiente, * anterior;
};

Compras* listaCompras = nullptr;

void insertarCompras(char[], int, int);


int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, PSTR cmdLine, int cShow) {

	HWND hVentanaRegistro = CreateDialog(hInst, MAKEINTRESOURCE(IDD_MAIN_WINDOW), NULL, cVentanaRegistro);

	MSG msg; //Variable para los mensajes recibidos en la ventana
	ZeroMemory(&msg, sizeof(MSG));

	ShowWindow(hVentanaRegistro, cShow);

	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return 0;
}

LRESULT CALLBACK cVentanaRegistro(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)

	{
	case WM_COMMAND:
	{

		if (LOWORD(wParam) == IDC_INICIO_SESION && HIWORD(wParam) == BN_CLICKED)
		{

			HWND hNombreUsuaro = GetDlgItem(hwnd, IDC_USER_NAME);

			int iUsuarioLength = GetWindowTextLength(hNombreUsuaro);

			char nombre[50];

			GetWindowText(hNombreUsuaro, nombre, iUsuarioLength + 1);

			if (iUsuarioLength < 1)
			{
				MessageBox(NULL, "Debe rellenar todos los campos", "Advertencia", MB_OK);
			}
			else
			{
				EndDialog(hwnd, 0);
				HWND hMenuWnd = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MIS_COMPRAS), hwnd, cVentanaDeCompras);
				//Muestra la nueva ventana
				ShowWindow(hMenuWnd, SW_SHOW);
			}

		}

	}break;

	case WM_CLOSE:
	{
		DestroyWindow(hwnd);
	}break;

	case WM_DESTROY:
	{
		PostQuitMessage(1);
	}break;

	}

	return FALSE;
}


LRESULT CALLBACK cVentanaDeCompras(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_INITDIALOG:
	{
		HWND hListCitas = GetDlgItem(hwnd, IDC_LIST_COMPRAS);
		//SendMessage(hListCitas, LB_ADDSTRING, NULL, (LPARAM)"Sin citas por el momento");

		Compras* actual = listaCompras;

		if (actual == nullptr)
		{
			SendMessage(hListCitas, LB_ADDSTRING, NULL, (LPARAM)"Sin compras por el momento");
		}
		else
		{

			while (actual != nullptr)
			{
				char nombreYEvento[50];

				//char evento[20];
				switch (actual->indiceEvento)
				{
				case 0: strcpy_s(nombreYEvento, " Ariana Grande - 12 de diciembre"); break; // pendiente
				case 1: strcpy_s(nombreYEvento, " Grupo Marrano - 20 de diciembre"); break; // efectuada
				case 2: strcpy_s(nombreYEvento, " Eminem - 28 de diciembre"); break; // cancelada
				}

				SendMessage(hListCitas, LB_ADDSTRING, 0, (LPARAM)nombreYEvento);
				actual = actual->siguiente;
			}
		}

	}break;

	case WM_COMMAND:
	{

		switch (LOWORD(wParam))
		{
		case ID_MISCOMPRAS:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaCompras = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MIS_COMPRAS), hwnd, cVentanaDeCompras);
			ShowWindow(hVentanaCompras, SW_SHOW);

		}break;

		case ID_EVENTOSDELMES:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaEventos = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_EVENTOS_MES), hwnd, cVentanaEventos);
			ShowWindow(hVentanaEventos, SW_SHOW);
		}break;

		case ID_VENTADEBOLETOS:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaBoletos = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_VENTA_BOLETOS), hwnd, cVentanaVentaBoletos);
			ShowWindow(hVentanaBoletos, SW_SHOW);
		}break;

		}



	} break;
	
	case WM_CLOSE:
	{
		EndDialog(hwnd, 0);
		HWND hVentanaRegistro = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MAIN_WINDOW), NULL, cVentanaRegistro);
		ShowWindow(hVentanaRegistro, SW_SHOW);
	}break;

	}

	return FALSE;
}


LRESULT CALLBACK cVentanaVentaBoletos(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_INITDIALOG:
	{
		HWND hComboEventos = GetDlgItem(hwnd, IDC_COMBO_EVENTOS);

		SendMessage(hComboEventos, CB_ADDSTRING, 0, (LPARAM)"Ariana Grande - 12 de diciembre");
		SendMessage(hComboEventos, CB_ADDSTRING, 0, (LPARAM)"Grupo Marrano - 20 de diciembre");
		SendMessage(hComboEventos, CB_ADDSTRING, 0, (LPARAM)"Eminem - 28 de diciembre");

		HWND hComboPromo = GetDlgItem(hwnd, IDC_COMBO_PROMO);

		SendMessage(hComboPromo, CB_ADDSTRING, 0, (LPARAM)"Promoci�n 2x1");
		SendMessage(hComboPromo, CB_ADDSTRING, 0, (LPARAM)"Descuento 10%");


	}break;

	case WM_COMMAND:
	{

		switch (LOWORD(wParam))
		{
		case ID_MISCOMPRAS:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaCompras = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MIS_COMPRAS), hwnd, cVentanaDeCompras);
			ShowWindow(hVentanaCompras, SW_SHOW);

		}break;

		case ID_EVENTOSDELMES:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaEventos = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_EVENTOS_MES), hwnd, cVentanaEventos);
			ShowWindow(hVentanaEventos, SW_SHOW);
		}break;

		case ID_VENTADEBOLETOS:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaBoletos = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_VENTA_BOLETOS), hwnd, cVentanaVentaBoletos);
			ShowWindow(hVentanaBoletos, SW_SHOW);
		}break;

		}

		//int indiceEvento = 0;
		if (LOWORD(wParam) == IDC_COMPRAR && HIWORD(wParam) == BN_CLICKED)
		{
			HWND hCosto = GetDlgItem(hwnd, IDC_COSTO_EVENTO);
			HWND hComboEvento = GetDlgItem(hwnd, IDC_COMBO_EVENTOS);
			HWND hComboPromo = GetDlgItem(hwnd, IDC_COMBO_PROMO);

			int iCosto = GetWindowTextLength(hCosto);
			int indiceEvento = SendMessage(hComboEvento, CB_GETCURSEL, 0, 0); //Indice del evento
			int indicePromo = SendMessage(hComboPromo, CB_GETCURSEL, 0, 0); //Indice de la promo

			char costoEvento[20];
			GetWindowText(hCosto, costoEvento, iCosto + 1);

			if (iCosto < 1 || indiceEvento == CB_ERR) {
				MessageBox(NULL, "Debe rellenar todos los campos", "Advertencia", MB_OK);
			}
			else
			{
				/*char indiceDelEvento[20];
				_itoa_s(indiceEvento, indiceDelEvento, 10);*/
				insertarCompras(costoEvento, indiceEvento, indicePromo);
			}

		}

	}break;

	case WM_CLOSE:
	{
		EndDialog(hwnd, 0);
		HWND hVentanaRegistro = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MAIN_WINDOW), NULL, cVentanaRegistro);
		ShowWindow(hVentanaRegistro, SW_SHOW);
	}break;

	}

	return FALSE;
}

LRESULT CALLBACK cVentanaEventos(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_INITDIALOG:
	{
		MessageBox(NULL, "Mostrando Eventos", "Eventos", MB_OK);
	}break;

	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case ID_MISCOMPRAS:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaCompras = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MIS_COMPRAS), hwnd, cVentanaDeCompras);
			ShowWindow(hVentanaCompras, SW_SHOW);

		}break;

		case ID_EVENTOSDELMES:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaEventos = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_EVENTOS_MES), hwnd, cVentanaEventos);
			ShowWindow(hVentanaEventos, SW_SHOW);
		}break;

		case ID_VENTADEBOLETOS:
		{
			EndDialog(hwnd, 0);
			HWND hVentanaBoletos = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_VENTA_BOLETOS), hwnd, cVentanaVentaBoletos);
			ShowWindow(hVentanaBoletos, SW_SHOW);
		}break;

		}
	}break;

	case WM_CLOSE:
	{
		EndDialog(hwnd, 0);
		HWND hVentanaRegistro = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_MAIN_WINDOW), NULL, cVentanaRegistro);
		ShowWindow(hVentanaRegistro, SW_SHOW);
	}

	}

	return FALSE;
}


void insertarCompras(char precio[], int indice, int promo)
{
	Compras* nuevaCompra = new Compras;
	strcpy_s(nuevaCompra->precio, precio);
	nuevaCompra->indiceEvento = indice;
	nuevaCompra->indicePromo = promo;
	//strcpy_s(nuevaCompra->indiceEvento, indice);

	nuevaCompra->siguiente = nullptr;
	nuevaCompra->anterior = nullptr;

	if (listaCompras == nullptr) {
		// La lista est� vac�a, el nuevo doctor ser� el primero.
		listaCompras = nuevaCompra;
	}
	else {
		// Agrega el nuevo doctor al final de la lista.
		Compras* ultimo = listaCompras;
		while (ultimo->siguiente != nullptr) {
			ultimo = ultimo->siguiente;
		}
		nuevaCompra->anterior = ultimo;
		ultimo->siguiente = nuevaCompra;
	}

	char mostrarPromo[40], precioFinal[20];
	float costoConIVA = 0;
	float precioDeCompra = 0;
	precioDeCompra = atof(nuevaCompra->precio);

	switch (nuevaCompra->indicePromo)
	{
	case 0:
		strcpy_s(mostrarPromo, "Promoci�n del 2x1 aplicada");
		break;

	case 1:
		strcpy_s(mostrarPromo, "Promoci�n del 10% de descuento aplicada");
		precioDeCompra *= .9;
		break;

	}

	costoConIVA = precioDeCompra * IVA;
	sprintf_s(precioFinal, "%f", costoConIVA);

	MessageBox(NULL, "Compra hecha", "Yupi", MB_OK);
	MessageBox(NULL, mostrarPromo, "Promoci�n", MB_OK);
	MessageBox(NULL, precioFinal, "Precio a pagar", MB_OK);
}